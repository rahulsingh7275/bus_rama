<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Payment extends Model
{
    use HasFactory;
    protected $fillable = [
        'ticket_id',
        'gateway',
        'gateway_mode',
        'contact',
        'order_id',
        'payment_id',
        'currency',
        'amount',
        'receipt',
        'response',
        'status',
        'refund_status',
        'refund_amount',
    ];
}
