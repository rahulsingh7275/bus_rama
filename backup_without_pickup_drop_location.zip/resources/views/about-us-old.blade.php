@extends('layouts.app')

@section('content')

<main>
    <section class="inner-banner bg_img" style="background: url({{asset('/')}}Content/Images/AboutBack.jpg) center">
        <div class="container">
            <div class="inner-banner-content">
                <h2 class="title">About</h2>
            </div>
        </div>
    </section>


    <section class="about-section padding-top padding-bottom">
        <div class="container">
            <div class="row mb-4 mb-md-5 gy-4">
                <div class="col-lg-7 col-xl-6">
                    <div class="about-content">
                        <div class="section-header">
                            <h2 class="title">Know Few Words About Autobus</h2>
                        </div>
                        <p>
                            <div class="section-header" style="margin-bottom:20px;color:rgb(119,119,119);font-family:Lato, sans-serif;"><p style="margin-right:0px;margin-left:0px;padding:0px;font-size:18px;color:rgb(66,66,72);">Lorem Lorem ipsum dolor, sit amet consectetur adipisicing elit. Nulla sit reprehenderit non voluptas quam quod facilis, doloribus impedit magni. Numquam ipsum placeat ullam alias temporibus non quas aperiam odio pariatur.</p></div>
                        <p style="margin-right:0px;margin-left:0px;padding:0px;color:rgb(119,119,119);font-family:Lato, sans-serif;font-size:16px;">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Eos eveniet inventore blanditiis maxime doloremque minima. Quisquam, ex! Architecto laudantium culpa cupiditate hic facere est magni, possimus repudiandae, rerum eius omnis.lore Lorem ipsum dolor sit amet consectetur adipisicing elit. Doloremque excepturi sed possimus recusandae temporibus tempore, aspernatur, autem sequi natus iste fugit. Eaque vero temporibus illum quis beatae quam officia ad.ri sed possimus recusandae temporibus tempore, aspernatur, autem sequi natus iste fugit. Eaque vero temporibus sed possimus recusandae temporibus tempore, aspernatur, autem sequi natus iste fugit. Eaque vero temporibus illum quis beatae quam officia ad.</p>                    </p>
                    </div>
                </div>
                <div class="col-lg-5 col-xl-6">
                    <div class="about-thumb">
                        <img src="{{asset('/')}}Content/Images/AboutImg.jpg" alt="Know Few Words About Autobus">
                    </div>
                </div>
            </div>
            <div class="about-details">
                <div class="item">
                    <h4 class="title">About Us</h4>
                    <p>
                        <div class="item" style="margin-bottom:30px;color:rgb(119,119,119);font-family:Lato, sans-serif;"><p style="margin-right:0px;margin-bottom:10px;margin-left:0px;padding:0px;">Lorem ipsum dolor sit amet consectetur adipisicing elit. Facilis vel temporibus voluptatum quidem, blanditiis libero assumenda beatae ducimus placeat odio aperiam tenetur animi, reiciendis reprehenderit expedita nostrum a eum. Quod. Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatum ipsum necessitatibus eum non quisquam! Quo esse est minima vero dolores eveniet voluptatibus nam. Veniam ad quae illum tenetur voluptates veritatis?</p><p style="margin-right:0px;margin-bottom:10px;margin-left:0px;padding:0px;">Lorem ipsum dolor sit amet consectetur adipisicing elit. Facilis vel temporibus voluptatum quidem, blanditiis libero assumenda beatae ducimus placeat odio aperiam tenetur animi, reiciendis reprehenderit expedita nostrum a eum. Quod. Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatum ipsum necessitatibus eum non quisquam! Quo esse est minima vero dolores eveniet voluptatibus nam. Veniam ad quae illum tenetur voluptates veritatis?</p></div><div class="item" style="margin-bottom:0px;color:rgb(119,119,119);font-family:Lato, sans-serif;"><h4 class="title" style="margin-bottom:10px;font-weight:600;line-height:1.2;font-size:24px;color:rgb(66,66,72);font-family:Georama, sans-serif;">Why Make Bus Reservations With AutoBus</h4><p style="margin-right:0px;margin-bottom:10px;margin-left:0px;padding:0px;">Lorem ipsum dolor sit amet consectetur adipisicing elit. Facilis vel temporibus voluptatum quidem, blanditiis libero assumenda beatae ducimus placeat odio aperiam tenetur animi, reiciendis reprehenderit expedita nostrum a eum. Quod. Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatum ipsum necessitatibus eum non quisquam! Quo esse est minima vero dolores eveniet voluptatibus nam. Veniam ad quae illum tenetur voluptates veritatis?</p><ul class="info" style="margin-top:15px;margin-bottom:-7px;margin-left:15px;"><li style="list-style:disc;padding:3px 0px;">Free Cancellation</li><li style="list-style:disc;padding:3px 0px;">Instant Refunds</li><li style="list-style:disc;padding:3px 0px;">Easy & Quick Bus Booking</li><li style="list-style:disc;padding:3px 0px;">Exciting Cashback & Bus Offers</li><li style="list-style:disc;padding:3px 0px;">Best Price Assured</li><li style="list-style:disc;padding:3px 0px;">24/7 Customer Assistance</li></ul></div><h2 class="title" style="margin-top:-10px;margin-bottom:15px;font-weight:600;line-height:1.2;font-size:36px;color:rgb(66,66,72);font-family:Georama, sans-serif;"></h2>
                    </p>
                </div>
            </div>
        </div>
    </section>
    <section class="faq-section padding-top padding-bottom">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-6 col-md-8">
                    <div class="section-header text-center">
                        <h2 class="title">Frequently Asked Questions</h2>
                        <p>Nobis minus earum perferendis nemo cupiditate optio, rem neque incidunt quia laborum ut praesentium corporis quam exercitationem, atque illo aut excepturi cum.</p>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-lg-6">
                    <div class="faq-wrapper">
                        <div class="faq-item">
                            <div class="faq-title">
                                <span class="icon"></span>
                                <h5 class="title">Can we choose corporation buses from anywhere?</h5>
                            </div>
                            <div class="faq-content">
                                <p>Orangu ipsum dolor sit amet consectetur adipisicing elit. Sed minima porro aliquid eius laudantium ad quod a corrupti impedit, reiciendis iusto ut aperiam tenetur fuga repellendus tempore necessitatibus omnis libero?</p>
                            </div>
                        </div>
                        <div class="faq-item">
                            <div class="faq-title">
                                <span class="icon"></span>
                                <h5 class="title">Can we choose corporation buses from anywhere?</h5>
                            </div>
                            <div class="faq-content">
                                <p>Orangu ipsum dolor sit amet consectetur adipisicing elit. Sed minima porro aliquid eius laudantium ad quod a corrupti impedit, reiciendis iusto ut aperiam tenetur fuga repellendus tempore necessitatibus omnis libero?</p>
                            </div>
                        </div>
                        <div class="faq-item">
                            <div class="faq-title">
                                <span class="icon"></span>
                                <h5 class="title">What is Lorem Ipsum?</h5>
                            </div>
                            <div class="faq-content">
                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="faq-wrapper">
                        <div class="faq-item">
                            <div class="faq-title">
                                <span class="icon"></span>
                                <h5 class="title">Can we choose corporation buses from anywhere?</h5>
                            </div>
                            <div class="faq-content">
                                <p>Orangu ipsum dolor sit amet consectetur adipisicing elit. Sed minima porro aliquid eius laudantium ad quod a corrupti impedit, reiciendis iusto ut aperiam tenetur fuga repellendus tempore necessitatibus omnis libero?</p>
                            </div>
                        </div>
                        <div class="faq-item">
                            <div class="faq-title">
                                <span class="icon"></span>
                                <h5 class="title">Why do we use it?</h5>
                            </div>
                            <div class="faq-content">
                                <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>

@endsection
